# Loaders Essenciais (gratuito)

Vinte e dois loaders e spinners em **CSS puro** — nenhum deles usa JavaScript. Cor, tamanho e velocidade são controlados por três variáveis CSS, e cada loader já vem com `role="status"` e o texto escondido "Carregando…" para leitores de tela.

Abra `demo/index.html` direto no navegador: a galeria deixa você mudar a cor, a velocidade e o tamanho ao vivo e copiar o HTML de qualquer loader com um clique.

## Os 22 loaders

| Classe | Nome | Observação |
|--------|------|------------|
| `.ld-anel` | Anel | borda com trecho que gira |
| `.ld-pontos` | Pontos pulsando | 3 `<i>` |
| `.ld-barras` | Equalizador | 5 `<i>` |
| `.ld-orbita` | Órbita | só pseudo-elementos |
| `.ld-quadrado` | Quadrado dobrando | 4 `<i>` |
| `.ld-onda` | Onda | 5 `<i>` |
| `.ld-progresso` | Progresso indeterminado | barra que desliza |
| `.ld-ampulheta` | Ampulheta | areia desce e ela gira |
| `.ld-coracao` | Coração batendo | forma geométrica, dois batimentos |
| `.ld-radar` | Radar | varredura + alvo |
| `.ld-gota` | Gota | gota cai e abre uma onda |
| `.ld-contorno` | Contorno desenhando | único com SVG (`<path pathLength="1">`) |
| `.ld-esqueleto` | Esqueleto | cartão "fantasma" com brilho varrendo (4 `<i>`) |
| `.ld-blob` | Blob líquido | massa que muda de forma, com volume e reflexo |
| `.ld-conico` | Anel cônico | cauda em degradê (conic-gradient + mask) e cabeça com brilho |
| `.ld-enchendo` | Enchendo | água com duas ondas que sobe e desce num copo redondo |
| `.ld-newton` | Pêndulo de Newton | 5 esferas (`<i>`), as pontas se revezam |
| `.ld-moeda` | Moeda 3D | gira em rotateY; sombra achata quando fica de perfil |
| `.ld-cubo` | Cubo 3D | 6 faces (`<i>`) com sombreamento, preserve-3d |
| `.ld-dna` | Hélice DNA | 8 colunas (`<i>`), duas fitas em fases opostas |
| `.ld-percentual` | Percentual | anel que enche de 0 a 100% com o número no meio (`@property`) |
| `.ld-digitando` | Digitando | balão de chat com três pontos pulando (3 `<i>`) |

## Estrutura de arquivos

```
demo/
├── index.html   → a galeria (referência de marcação)
├── estilo.css   → tokens, base dos loaders, os 22 blocos e a moldura da página
└── script.js    → SÓ a interface da galeria (painel + copiar). Os loaders não usam.
LEIAME.md        → este guia
```

O `estilo.css` é dividido em: **1. Tokens**, **2. Base dos loaders**, **3. Os 22 loaders** (3.1–3.12 clássicos, 3.13–3.22 realistas e 3D), **4. Página da galeria** (descartável) e **5. Movimento reduzido**.

## Como copiar um loader para o seu projeto

1. Na galeria, **clique no cartão** (ou use o botão *Copiar* com o teclado). O HTML vai para a área de transferência — se você mexeu na cor, velocidade ou tamanho, ele já sai com um `style="--ld-cor:…"`.
2. Cole no seu HTML. Exemplo:

   ```html
   <div class="ld-anel" role="status"><span class="ld-sr">Carregando…</span></div>
   ```
3. No `estilo.css`, copie o bloco **"2. Base dos loaders"** (variáveis internas + `.ld-sr`) e o bloco do loader escolhido (ex.: **3.1 ANEL**) junto com seus `@keyframes`.
4. Copie também as variáveis `--ld-*` do `:root` (seção 1).

> O bloco "Base" tem uma lista com as 22 classes. Ao levar só um loader, deixe apenas a sua classe nessa lista.

## Como trocar cor, tamanho e velocidade

As três variáveis públicas ficam no `:root` do `estilo.css`:

```css
:root {
  --ld-cor: #ee4d2a;       /* cor principal */
  --ld-tamanho: 56px;      /* tamanho de referência (altura do loader) */
  --ld-velocidade: 1s;     /* duração base — MENOR = MAIS RÁPIDO */
}
```

Elas valem para todos os loaders da página. Para mudar **um só**, defina no próprio elemento (ou em qualquer ancestral):

```html
<div class="ld-radar" style="--ld-cor:#2f6bff; --ld-tamanho:80px; --ld-velocidade:.6s" role="status">
  <span class="ld-sr">Carregando…</span>
</div>
```

Um loader dentro de um botão, por exemplo:

```css
.botao .ld-anel { --ld-tamanho: 18px; --ld-cor: currentColor; }
```

Cada loader guarda as variáveis em nomes internos curtos (`--c`, `--t`, `--v`) e calcula tudo a partir deles — por isso o tamanho escala proporcionalmente, inclusive as bordas.

## Acessibilidade

- Cada loader tem `role="status"` e `<span class="ld-sr">Carregando…</span>` (visível só para leitores de tela). Troque o texto por algo mais específico quando quiser: "Enviando arquivo…".
- Quando o carregamento terminar, **remova** o loader do DOM (ou esconda-o) para o leitor de tela não continuar anunciando.
- **prefers-reduced-motion:** os loaders não somem (eles indicam que algo está acontecendo), mas ficam **2,5× mais lentos** via `--ld-reduz`. Se preferir pará-los, adicione `animation: none` aos loaders dentro da media query da seção 5.

## Compatibilidade

Navegadores atuais (Chrome/Edge 111+, Safari 16.2+, Firefox 113+) — o motivo é o uso de `color-mix()` nas trilhas translúcidas. O **Percentual** anima o número com `@property` (Chrome 85+, Safari 16.4+, Firefox 128+); em navegadores sem suporte o anel aparece cheio e sem número. Em navegadores mais antigos, troque as chamadas `color-mix(in srgb, var(--c) 18%, transparent)` por uma cor `rgba` fixa.

O script da galeria é independente: fontes carregadas do Google Fonts (única chamada externa) e nenhuma biblioteca.

## Licença de uso

Gratuito para projetos pessoais e comerciais. Não revenda nem redistribua o arquivo original como produto.
