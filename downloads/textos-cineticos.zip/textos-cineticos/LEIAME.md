# Textos Cinéticos

Biblioteca de tipografia em movimento em **HTML, CSS e JavaScript puros** — sem dependências, sem build.
Dezoito efeitos de texto, cada um ativado por **um data-atributo**, que disparam quando o texto entra na tela
(`IntersectionObserver`). A página `demo/index.html` mostra todos, cada um com um botão **Repetir**.

## Estrutura

```
demo/
  index.html   página de demonstração (hero + galeria + "como usar")
  estilo.css   tokens (:root), estilos de cada efeito e layout da demo
  script.js    biblioteca TextosCineticos (+ botões "Repetir" da demo, no fim do arquivo)
LEIAME.md
```

Abra `demo/index.html` direto no navegador (funciona via `file://`). A única URL externa é o Google Fonts (só tipografia).

## Instalar no seu projeto

1. Copie `estilo.css` e `script.js` (a seção **BIBLIOTECA — EFEITOS** do CSS é a que importa; o restante é o layout da demo).
2. Inclua no HTML:

```html
<script>document.documentElement.classList.add("js");</script> <!-- no <head>: evita o "pisca" do texto cru -->
<link rel="stylesheet" href="estilo.css">
<script src="script.js" defer></script>
```

3. Marque os textos: `<h2 data-tc="revelar">Seu título</h2>`. Pronto — o script se inicia sozinho.

## Os 18 efeitos

| Efeito | Marcação | Opções |
|---|---|---|
| **revelar** — letras sobem de dentro de uma máscara, em cascata | `<h2 data-tc="revelar">Texto</h2>` | `data-passo` (ms entre letras, padrão 30), `data-atraso` (s) |
| **decodificar** — caracteres embaralhados que se resolvem | `<p data-tc="decodificar">Texto</p>` | `data-duracao` (s, padrão 1.4), `data-atraso` |
| **digitar** — máquina de escrever com cursor, alternando frases | `<span data-tc="digitar" data-frases="um\|dois\|três"></span>` | `data-frases` (separe com `\|`), `data-velocidade` (ms/letra, padrão 60), `data-pausa` (ms, padrão 1600), `data-atraso` |
| **varredura** — faixa de cor varrendo o texto (`background-clip: text`) | `<h2 data-tc="varredura">Texto</h2>` | `data-atraso` |
| **onda** — letras oscilando em loop contínuo | `<p data-tc="onda">Texto</p>` | — |
| **desfocar** — palavras saem do desfoque uma a uma | `<p data-tc="desfocar">Texto</p>` | `data-passo` (ms entre palavras, padrão 110), `data-atraso` |
| **contador** — odômetro com dígitos rolando, formatado em pt-BR | `<span data-tc="contador" data-valor="1284750"></span>` | `data-valor`, `data-decimais`, `data-prefixo` (ex.: `R$ `), `data-sufixo` (ex.: `%`), `data-atraso` |
| **destaque** — marca-texto desenhado atrás dos `<mark>` | `<p data-tc="destaque">Veja <mark>isto</mark> e <mark data-cor="tomate">isto</mark>.</p>` | `data-atraso`; `data-cor="tomate"` no `<mark>` |
| **cair** — letras despencam de cima, quicam e assentam | `<h2 data-tc="cair">Texto</h2>` | `data-passo` (padrão 45), `data-atraso` |
| **girar** — cada letra vira em 3D a partir da base | `<p data-tc="girar">Texto</p>` | `data-passo` (padrão 35), `data-atraso` |
| **glitch** — cópias do texto em vermelho/limão, recortadas em fatias, tremem e somem | `<h2 data-tc="glitch">Texto</h2>` | `data-atraso` |
| **neon** — letreiro que pisca até acender, com brilho | `<p data-tc="neon">Texto</p>` | `data-atraso`; cor em `--neon` (padrão `--limao`) |
| **fatiar** — o texto é cortado em fatias horizontais que deslizam de lados opostos | `<h2 data-tc="fatiar">Texto</h2>` | `data-fatias` (padrão 3), `data-atraso` |
| **trocar** — a palavra sobe e a próxima entra por baixo, em loop; a largura acompanha | `<span data-tc="trocar" data-palavras="rápido\|bonito\|simples"></span>` | `data-palavras` (separe com `\|`), `data-pausa` (ms, padrão 1800), `data-atraso` |
| **contorno** — letras só com o traço, que se preenchem uma a uma | `<h2 data-tc="contorno">Texto</h2>` | `data-passo` (padrão 40), `data-atraso`; `<em>` fica na cor de acento |
| **gradiente** — faixa de cores correndo pelo texto, em loop | `<p data-tc="gradiente">Texto</p>` | — (cores no `background-image` do efeito) |
| **espalhar** — letras chegam de posições aleatórias, giradas e desfocadas, e se encaixam | `<h2 data-tc="espalhar">Texto</h2>` | `data-passo` (padrão 28), `data-atraso` |
| **riscar** — risca o `<s>` com um traço e revela o `<ins>` ao lado | `<p data-tc="riscar">Não é <s>enfeite</s><ins>estratégia</ins>.</p>` | `data-atraso`; pares `<s>`+`<ins>` em sequência |

Dicas:

- `revelar`, `onda`, `desfocar`, `decodificar`, `cair`, `girar`, `contorno` e `espalhar` preservam `<em>`, `<strong>` e `<br>` dentro do texto. `glitch`, `neon`, `fatiar` e `gradiente` tratam o texto inteiro (sem marcação interna).
- `trocar` e `digitar` são laços: o `Repetir` reinicia; com uma única palavra, `trocar` fica parado nela.
- `contador` aceita decimais com ponto no `data-valor`: `data-valor="98.4" data-decimais="2"` → `98,40`.
- No `destaque`, os `<mark>` são desenhados na ordem em que aparecem; funciona também em marcas que quebram de linha.

## API (JavaScript)

```js
TextosCineticos.iniciar();                          // prepara todos os [data-tc] da página
TextosCineticos.iniciar(document.querySelector("#hero")); // ou só uma área (útil em conteúdo inserido depois)
TextosCineticos.repetir(elemento);                  // toca de novo o elemento (ou tudo que há dentro dele)
TextosCineticos.efeitos;                            // ["revelar", "onda", ... 18 nomes]
```

- A biblioteca já se inicia ao carregar. Para controlar você mesmo, use `<body data-tc-manual>` e chame `iniciar()`.
- Os botões **Repetir** da demo usam `<button data-repetir>` dentro de um contêiner `data-area` (código no fim do `script.js`; pode apagar).

## Trocar fontes e cores

Tudo está no `:root` do `estilo.css`:

```css
:root {
  --fundo: #0c0c0b;          /* fundo */
  --creme: #f2eee3;          /* cor do texto */
  --creme-apagado: #4b4842;  /* texto "ainda não varrido" (varredura) */
  --tomate: #ff4a3d;         /* acento 1 */
  --limao: #e9ff5c;          /* acento 2 */

  --fonte-display: "Unbounded", "Archivo Black", system-ui, sans-serif;
  --fonte-serif: "Instrument Serif", Georgia, serif;
  --fonte-mono: "JetBrains Mono", ui-monospace, monospace;

  --margem: clamp(1rem, 3vw, 2.5rem);
  --ease-saida: cubic-bezier(0.16, 1, 0.3, 1);   /* curva dos efeitos */
}
```

Para trocar uma fonte, altere o `<link>` do Google Fonts no `index.html` e o token correspondente.
O ritmo de cada efeito se ajusta pelos data-atributos (acima) ou pelas durações em `estilo.css`.

## Acessibilidade e movimento

- Nos efeitos que separam letras, o elemento recebe `aria-label` com o texto completo e os `<span>` das letras ficam com `aria-hidden="true"` (em elementos que não são títulos, também recebe `role="group"` para o rótulo ser lido).
- Com `prefers-reduced-motion: reduce`, todo texto aparece direto no estado final, sem animação (os botões Repetir somem).
- Os botões têm foco visível e a página não tem rolagem horizontal de 1440px até 360px.

## Como funciona (resumo)

`script.js` divide o texto em `.tc-palavra > .tc-letra` (com variáveis `--p`/`--i` para o escalonamento), observa os elementos
e, ao entrarem na tela, liga a classe `.tc-ativo`. A maior parte dos efeitos é CSS puro (transições/`@keyframes` guiadas por essas
variáveis); `decodificar`, `digitar`, `trocar` e `contador` têm um pouco de JS para o embaralhado, os laços de frases/palavras e as fitas de dígitos.
O código é comentado em português.
