# Ícones Animados

20 ícones SVG originais, em traço linear sobre grade 24×24 com um preenchimento duotone sutil (desligável), cada um com uma microanimação em CSS. As animações tocam quando o mouse passa por cima, quando o elemento recebe foco pelo teclado ou quando você adiciona uma classe no toque/clique. Não há dependências e não há etapa de build.

| Ícone | Classe | Animação |
|---|---|---|
| Sino | `ia-sino` | balança a partir do topo, com o badalo atrasado |
| Coração | `ia-coracao` | batida dupla; o preenchimento duotone se intensifica |
| Lixeira | `ia-lixeira` | a tampa abre presa na dobradiça |
| Cadeado | `ia-cadeado` | a alça sobe e gira (destrava) |
| Envelope | `ia-envelope` | a aba vira para cima |
| Engrenagem | `ia-engrenagem` | gira 90° com aceleração suave |
| Lupa | `ia-lupa` | pulsa e solta uma onda da lente |
| Confirmar | `ia-confirmar` | anel e check se desenham (stroke-dasharray) |
| Download | `ia-download` | a seta desce e reaparece por cima |
| Upload | `ia-upload` | a seta sobe e reaparece por baixo |
| Menu | `ia-menu` | as três linhas viram um X |
| Play / Pause | `ia-play` | o triângulo gira e dá lugar às barras de pausa |
| Estrela | `ia-estrela` | gira 72° e solta brilhos |
| Chuva | `ia-chuva` | a nuvem flutua e as gotas caem (contínuo) |
| Wi-Fi | `ia-wifi` | as ondas acendem de dentro para fora (contínuo) |
| Bateria | `ia-bateria` | as barras de carga enchem uma a uma (contínuo) |
| Casa | `ia-casa` | dá um pulinho (achata, estica, assenta) e a porta acende |
| Usuário | `ia-usuario` | a cabeça acena duas vezes, os ombros acompanham |
| Olho | `ia-olho` | pisca e a pupila olha para os lados |
| Compartilhar | `ia-compartilhar` | o nó pulsa e os elos se desenham até os outros dois |

### Desenho

- Grade 24×24 com 2 px de respiro em volta; traço 1,75 com pontas e juntas arredondadas em todos.
- Formas-guia (keylines) consistentes: círculo de raio 9, quadrado de 16, retângulos de 18×14 / 15×18, cantos com raio 2,5–2,75. Os ícones foram comparados lado a lado em 24, 32 e 64 px para que nenhum pareça maior ou menor que os outros (o play é deslocado para a direita para o centro óptico bater).
- **Duotone:** cada ícone tem uma camada `.ia-tom` — a forma principal preenchida com a mesma cor do traço a 16% de opacidade. Dá volume sem virar ícone cheio. No hover a camada fica um pouco mais forte.

## Estrutura

```
demo/
├── index.html   → galeria com os 20 ícones (o SVG de cada um está aqui)
├── icones.css   → A BIBLIOTECA: variáveis + animações dos ícones (é o que você leva)
├── estilo.css   → só o visual da página de demonstração
└── script.js    → só a galeria: ajustes ao vivo, copiar, baixar e buscar
```

Abra `demo/index.html` direto no navegador (funciona em `file://`). A fonte Outfit vem do Google Fonts; sem internet, a página usa a fonte do sistema.

## Como usar no seu projeto

1. Copie `icones.css` para o projeto e inclua no `<head>`:

   ```html
   <link rel="stylesheet" href="icones.css">
   ```

2. Na galeria, clique no cartão do ícone: o SVG completo vai para a área de transferência (já com as classes e as partes que a animação usa). Cole no seu HTML.

3. Coloque o ícone dentro de um elemento com a classe `ia-gatilho`. O hover e o foco desse elemento disparam a animação:

   ```html
   <button class="ia-gatilho" type="button">
     <svg class="ia-icone ia-sino" viewBox="0 0 24 24" …>…</svg>
     Notificações
   </button>
   ```

   Sem `ia-gatilho`, a animação toca ao passar o mouse sobre o próprio `<svg>`.

### Disparar no toque ou por código

Em telas de toque não existe hover. Adicione a classe `ia-ativo` no ícone (ou num pai) para tocar a animação; tire-a depois:

```js
function animarIcone(el) {
  el.classList.remove('ia-ativo');
  void el.offsetWidth;            // reinicia a animação
  el.classList.add('ia-ativo');
  setTimeout(() => el.classList.remove('ia-ativo'), 1600);
}
```

Nos ícones de estado (menu → X, play ↔ pause, cadeado, envelope, lixeira), deixar `ia-ativo` fixo mantém o estado final. Assim dá para usar o ícone de menu como botão de abrir/fechar:

```js
botaoMenu.addEventListener('click', () => {
  const aberto = botaoMenu.classList.toggle('ia-ativo');
  botaoMenu.setAttribute('aria-expanded', aberto);
});
```

## Trocar cores, tamanho, traço e velocidade

Tudo vem de variáveis no `:root` do `icones.css`. Mude lá para o site inteiro, ou num pai para um trecho só:

```css
:root {
  --ia-cor: currentColor;  /* padrão: herda a cor do texto */
  --ia-tamanho: 24px;
  --ia-traco: 1.75;        /* espessura em unidades da grade 24×24 */
  --ia-ritmo: 1;           /* 1,5 = 50% mais lento; 0,7 = mais rápido */
  --ia-tom: .16;           /* opacidade do preenchimento duotone (0 = só traço) */
}

.barra-lateral { --ia-cor: #2f5bd3; --ia-tamanho: 20px; }
```

### Só o traço (desligar o duotone)

Três jeitos, do mais amplo ao mais pontual:

```css
:root { --ia-tom: 0; }              /* no site inteiro */
```

```html
<nav class="ia-so-traco">…ícones…</nav>              <!-- num trecho -->
<svg class="ia-icone ia-sino ia-so-traco" …>…</svg>   <!-- num ícone só -->
```

Na galeria, a chave **Duotone** faz o mesmo e o SVG copiado/baixado sai sem a camada `.ia-tom`. Se preferir, apague os elementos `class="ia-tom"` do SVG colado.

A cor do ícone é `currentColor`, então ele também acompanha o `color` do botão em hover, tema escuro etc.

Para mudar a paleta da página de demonstração, edite o `:root` de `estilo.css` (`--ia-fundo`, `--ia-papel`, `--ia-tinta`, `--ia-sinal`, `--ia-linha`).

## Botão ".svg" (arquivo avulso)

O botão `.svg` de cada cartão baixa uma versão **estática**: sem as partes que só aparecem durante a animação (barras de pausa, brilhos da estrela, onda da lupa) e com a cor e a espessura escolhidas gravadas no arquivo (inclusive no preenchimento duotone, que respeita a chave da galeria). Use para Figma, apresentações ou qualquer lugar sem CSS.

## Acessibilidade

- Os ícones têm `aria-hidden="true"`: o nome acessível deve estar no botão ou link que os contém (texto visível ou `aria-label`).
- O foco pelo teclado (`:focus-visible`) dispara a mesma animação do hover.
- Com `prefers-reduced-motion: reduce`, nada se move: os estados finais aparecem direto (o menu vira X sem animação).

## Dicas de integração

- **React / Vue / Svelte:** cole o SVG como componente e troque `class` por `className` no React. O `icones.css` continua igual.
- **Ícone maior que o texto:** as animações usam `transform-box`, então funcionam em qualquer tamanho.
- **Somente alguns ícones:** cada bloco do `icones.css` é independente e está numerado; apague os que não usar.
- **Navegadores:** Chrome, Edge, Safari e Firefox atuais. Em navegadores sem `:has()`, só o foco dentro de um pai deixa de disparar a animação; hover, foco direto e `ia-ativo` continuam funcionando.

## Histórico de versões

- **1.2.0** — Desenho refeito em todos os ícones (keylines consistentes, centro óptico, cantos e pontas arredondados iguais); camada **duotone** `.ia-tom` desligável por `--ia-tom` ou `.ia-so-traco`; chave Duotone na galeria; 4 ícones novos (Casa, Usuário, Olho, Compartilhar) — agora são 20; galeria em 5 colunas.
- **1.1.0** — Galeria com busca, ajustes ao vivo, copiar SVG e baixar .svg.
- **1.0.0** — Primeira versão com 16 ícones.
